export { TabIcon } from './TabIcon';
