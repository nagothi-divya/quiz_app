export { SettingsIcon } from './SettingsIcon';
