export interface IconProps {
  strokeColor: string;
}
